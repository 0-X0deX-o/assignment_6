complete the assignment according to university specs -> save file -> complete your version of the project
    build off of the instructors specifications
        check file imports within the provided python files
        create two files
            assigned
            personal_level
        Use Camel Case 
        document total time spend at each level

Order standing table for home office
create a command line tool that outputs web inspect data to the user 
Order keyboard

learn how to extract 2D pngs from sprite sheets how to extract sprite sheets
learn pygame
concept of the game

Design workouts by the end of the day


choice of weapons associated with what fleet choice
    missile

chat feature

choice and incorporation of music
relay coordinates translated to geolocation coordinates
levels


planning phase: 33:00